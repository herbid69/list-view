package com.example.presiden;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
;

public class MainActivity extends AppCompatActivity {
    ListView listView;

    String[] fruitNames = {"Soekarno","Soeharto","Habibie","Abdurrahman Wahid","Megawati","Susilo bambang yudhoyono","Jokowi"};
    int[] fruitImages = {R.drawable.soekarno,R.drawable.soeharto,R.drawable.habibie,R.drawable.gusdur,R.drawable.megawati,R.drawable.sby,R.drawable.jokowi};
    String[] deskripsi = {
            "" +
                    "   Presiden ke 1 Soekarno. Biodata-Indonesia - Ir. Soekarno Hatta, lahir \n" +
                    "   pada 6 Juni 1901 di Surabaya, Jawa Timur\n" +
                    "   Ia adalah Presiden Indonesia pertama yang menjabat pada periode 1945 hingga 1966.",

            "" +
                    "   Jenderal Besar TNI H. M. Soeharto, adalah Presiden kedua Indonesia yang menjabat dari tahun 1967 sampai 1998,\n" +
                    "   menggantikan Soekarno.\n" +
                    "   Lahir: 8 Juni 1921, Kemusuk, Argomulyo, Sedayu, Bantul\n" +
                    "   Meninggal: 27 Januari 2008, Jakarta",
            "" +
                    "   Prof. Dr. Ing. H. Bacharuddin Jusuf Habibie, FREng adalah Presiden Republik Indonesia yang ketiga. \n" +
                    "   Sebelumnya, B.J. Habibie menjabat sebagai Wakil Presiden Republik Indonesia ke-7, menggantikan Try Sutrisno. B. J. \n" +
                    "   Habibie menggantikan Soeharto yang mengundurkan diri dari jabatan presiden pada tanggal 21 Mei 1998. B.J.\n" +
                    "   Lahir: 25 Juni 1936, Parepare\n" +
                    "   Meninggal: 11 September 2019, Rumah Sakit Pusat Angkatan Darat Gatot Soebroto, Jakarta",

            "" +
                    "   Dr. K. H. Abdurrahman Wahid atau yang akrab disapa Gus Dur adalah tokoh Muslim Indonesia \n" +
                    "   dan pemimpin politik yang menjadi Presiden Indonesia yang keempat dari tahun 1999 hingga 2001.\n" +
                    "   Ia menggantikan Presiden B.J. Habibie setelah dipilih oleh Majelis Permusyawaratan Rakyat hasil Pemilu 1999.\n" +
                    "   Lahir: 7 September 1940, Kabupaten Jombang\n" +
                    "   Meninggal: 30 Desember 2009, Jakarta",

            "" +
                    "   Dr. Hj. Dyah Permata Megawati Setyawati Soekarnoputri atau umumnya lebih dikenal sebagai Megawati Soekarnoputri \n" +
                    "   atau biasa disapa dengan panggilan \"Mbak Mega\" \n" +
                    "   adalah Presiden Indonesia yang kelima yang menjabat sejak 23 Juli 2001 sampai 20 Oktober 2004.\n" +
                    "   Lahir: 23 Januari 1947 (usia 72 tahun), Yogyakarta\n" +
                    "   Masa kepresidenan: 23 Juli 2001 – 20 Oktober 2004",

            "" +
                    "   Jenderal TNI Prof. Dr. H. Susilo Bambang Yudhoyono, M.A., GCB., AC. \n" +
                    "   adalah Presiden Indonesia ke-6 yang menjabat sejak 20 Oktober 2004 hingga 20 Oktober 2014.\n" +
                    "   Ia adalah Presiden pertama di Indonesia yang dipilih melalui jalur pemilu.\n" +
                    "   Ia, bersama Wakil Presiden Muhammad Jusuf Kalla, terpilih dalam Pemilu Presiden 2004. \n" +
                    "   Lahir: 9 September 1949 (usia 70 tahun)",

            "" +
                    "   Ir. H. Joko Widodo atau Jokowi adalah Presiden ke-7 Indonesia yang mulai menjabat sejak 20 Oktober 2014.\n" +
                    "   Ia terpilih bersama Wakil Presiden Muhammad Jusuf Kalla dalam Pemilu Presiden 2014. \n" +
                    "   Lahir: 21 Juni 1961 (usia 58 tahun), Surakarta\n" +
                    "   Jabatan saat ini: Presiden Indonesia sejak 2014"
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listview);

        CustomAdapter customAdapter = new CustomAdapter();
        listView.setAdapter(customAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Intent intent = new Intent(getApplicationContext(), ListdataActivity.class);
                intent.putExtra("name", fruitNames[i]);
                intent.putExtra("image", fruitImages[i]);

                intent.putExtra("deskripsi", deskripsi[i]);
                startActivity(intent);

            }
        });

    }

    private class CustomAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return fruitImages.length;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }
        @Override
        public View getView ( int i, View view, ViewGroup viewGroup){
            View view1 = getLayoutInflater().inflate(R.layout.row_data, null);
            //getting view in row_data
            TextView name = view1.findViewById(R.id.presiden);
            ImageView image = view1.findViewById(R.id.images);

            name.setText(fruitNames[i]);
            image.setImageResource(fruitImages[i]);
            return view1;

        }
    }
}