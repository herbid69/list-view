package com.example.listviewiconlatihan

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {
    val language = arrayOf<String>("Ruby","Rails","Python","Java Script","Php")
    val description = arrayOf<String>(

        "Ruby is an open-source and fully object-oriented programming language.",
        "Ruby on Rails is a server-side web application development framework written in Ruby language.",
        "Python is interpreted scripting  and object-oriented programming language.",
        "JavaScript is an object-based scripting language.",
        "PHP is an interpreted language, i.e., there is no need for compilation."

    )

    val imageId = arrayOf<Int>(
        R.drawable.ruby_image,
        R.drawable.rails_image,R.drawable.python_image,R.drawable.js_image,
        R.drawable.php_image,R.drawable.python_image

    )
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val myListAdapter = MyListAdapter(this,language,description,imageId)
        listView.adapter = myListAdapter

        listView.setOnItemClickListener(){adapterView, view, position, id ->

            if(position==0){
                Toast.makeText(this@MainActivity,"You selected Rubby",Toast.LENGTH_SHORT).show()
            }
            if(position==1){
                Toast.makeText(this@MainActivity,"You selected Ralls",Toast.LENGTH_SHORT).show()
            }
            if(position==2){
                Toast.makeText(this@MainActivity,"You selected Python",Toast.LENGTH_SHORT).show()
            }
            if(position==3){
                Toast.makeText(this@MainActivity,"You selected Java Script",Toast.LENGTH_SHORT).show()
            }
            if(position==4){
                Toast.makeText(this@MainActivity,"You selected PHP",Toast.LENGTH_SHORT).show()
            }
    }
    }
}